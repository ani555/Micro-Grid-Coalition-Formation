function [X , Qcp]= getOptimalPowerTransferPairs(S)
% This functions returns all the optimal power transfer pairs X after power
% exchange between buyer and seller microgrids and also between
% macrostation and microgrids. Qcp is a vector of remaining power after
% power exchange
global n Q dist;
pos = [];
neg = [];
for i = S
    if Q(i)>0
        pos = [pos,i];
    elseif Q(i)<0
        neg = [neg,i];
    end
end
m = length(pos)*length(neg);
peps = zeros(m,3);
k=1;
for I = pos
    for J = neg
        peps(k,:) = [I, J, dist(I+1,J+1)];
        k=k+1;
    end
end
X=[];
Qcp = Q;
while ~isempty(peps)
    sortrows(peps,3);
    I = peps(1,1);
    J = peps(1,2);
    Bij = B(I,J,Qcp);
    Plij = Ploss(I,J,Qcp);
    peps(1,:) = [];
    if abs(Qcp(I))==abs(Bij)
        markI = find(peps(:,1)==I);
        peps(markI,:)=[];
    elseif abs(Qcp(J))==abs(Bij-Plij)
        markJ = find(peps(:,2)==J);
        peps(markJ,:)=[];
    end
    Qcp(I) = Qcp(I) - Bij;
    Qcp(J) = min(Qcp(J)+Bij-Plij,0);
    X = [X;[I J Bij Plij]];
end
for i = S
    if Qcp(i)==0
        continue;
    else
        I=0;
        J = i;
    end
    Bij = B(I,J,Qcp);
    Plij = Ploss(I,J,Qcp);
    if Qcp(J)>0
        Qcp(J) = Qcp(J) - Bij;
        tmp = I;
        I = J;
        J = tmp;
    else
        Qcp(J) = min(Qcp(J)+Bij-Plij,0);
    end
    X = [X;[I J Bij Plij]];
end
function RUPscore = rup(i, j, q)
    RUPscore = (Ploss(0,i,q) + Ploss(0,j,q) - Ploss(i,j,q))/B(i,j,q);
end
end
