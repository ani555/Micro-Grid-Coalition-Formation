function Bij = B(i , j, q)
% This function computes power transfer between two pairs of microgrids i and j
% q is the vector containing the remaining power

global beta U0 U1 R;
b=0;
U=U1;
Bij = 0;
if i==0
    b = beta;
    U = U0; 
end
D=(1-b)^2 + 4*(R(i+1,j+1)*q(j))/(U*U);
if i==0
    if(q(j)>0)
        Bij = q(j);
    else
        r1 = (1-b - sqrt(D))*(U*U)/(2.0*R(i+1,j+1));
        r2 = (1-b + sqrt(D))*(U*U)/(2.0*R(i+1,j+1));
        if r1>0
            Bij = r1;
        else
            Bij = r2;
        end
    end     
elseif (i~=0)
    if abs(q(i))> abs(q(j))
        r1 = (1-b - sqrt(D))*(U*U)/(2.0*R(i+1,j+1));
        r2 = (1-b + sqrt(D))*(U*U)/(2.0*R(i+1,j+1));
        if r1>0
            Bij = r1;
        else
            Bij = r2;
        end
    else
        max_P =((1-b)*U*U)/(2*R(i+1,j+1));
        Bij = min(q(i),max_P);
    end
end
if D<0
    if i==0
        tmp=i;
        i=j;
        j=tmp;
    end
    Bij = min(q(i), ((1-b)*U*U)/(2*R(i+1,j+1)));
end
end
    